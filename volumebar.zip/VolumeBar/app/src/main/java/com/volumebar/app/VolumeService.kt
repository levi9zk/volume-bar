package com.volumebar.app

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout

class VolumeService : AccessibilityService() {

    private lateinit var audio: AudioManager
    private lateinit var wm: WindowManager

    private var track: FrameLayout? = null
    private var fill: View? = null
    private var attached = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideBar() }

    // Tamanhos da barra (em dp)
    private val barWidthDp = 8
    private val barHeightDp = 170
    private val marginDp = 10

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            val direction = if (code == KeyEvent.KEYCODE_VOLUME_UP) {
                AudioManager.ADJUST_RAISE
            } else {
                AudioManager.ADJUST_LOWER
            }
            val stream = currentStream()
            // flag 0 = não mostra o painel padrão do Android
            audio.adjustStreamVolume(stream, direction, 0)
            showBar(stream)
        }
        // true = o evento foi tratado aqui (o painel padrão não aparece)
        return true
    }

    private fun currentStream(): Int {
        return when (audio.mode) {
            AudioManager.MODE_IN_CALL,
            AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
    }

    private fun ensureViews() {
        if (track != null) return

        val corner = dp(barWidthDp).toFloat() / 2f

        val trackBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = corner
            setColor(0x66202020) // cinza escuro translúcido
        }

        val fillView = View(this).apply {
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val trackView = FrameLayout(this).apply {
            background = trackBg
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(
                fillView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    0,
                    Gravity.BOTTOM
                )
            )
            alpha = 0f
        }

        fill = fillView
        track = trackView
    }

    private fun showBar(stream: Int) {
        ensureViews()
        val t = track ?: return
        val f = fill ?: return

        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val vol = audio.getStreamVolume(stream)
        val fraction = vol.toFloat() / max.toFloat()

        val totalPx = dp(barHeightDp)
        val lp = f.layoutParams as FrameLayout.LayoutParams
        lp.height = (totalPx * fraction).toInt()
        f.layoutParams = lp

        if (!attached) {
            val params = WindowManager.LayoutParams(
                dp(barWidthDp),
                totalPx,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                x = dp(marginDp)
            }
            try {
                wm.addView(t, params)
                attached = true
            } catch (e: Exception) {
                return
            }
        }

        t.animate().cancel()
        t.animate().alpha(1f).setDuration(120).start()

        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 1500)
    }

    private fun hideBar() {
        val t = track ?: return
        t.animate().cancel()
        t.animate().alpha(0f).setDuration(250).withEndAction {
            if (attached) {
                try {
                    wm.removeView(t)
                } catch (e: Exception) {
                    // ignora
                }
                attached = false
            }
        }.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(hideRunnable)
        if (attached) {
            try {
                track?.let { wm.removeView(it) }
            } catch (e: Exception) {
                // ignora
            }
            attached = false
        }
        super.onDestroy()
    }
}
